import cv2
import numpy as np
from gmssl import sm9
from sklearn.cluster import KMeans
from scipy.spatial.distance import cosine

class SimpleBiometricLibrary:
    @staticmethod
    def extract_features(image_path):
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

        # Use ORB feature extractor
        orb = cv2.ORB_create(nfeatures=500)
        keypoints, descriptors = orb.detectAndCompute(image, None)

        # Cluster the features to get fixed-length output
        kmeans = KMeans(n_clusters=32)
        kmeans.fit(descriptors)
        histogram, _ = np.histogram(kmeans.labels_, bins=32, range=(0, 32))

        # Reshape the histogram to fit the required format
        if len(histogram.shape) == 1:
            histogram = histogram.reshape(-1, 1)
        elif histogram.shape[0] == 1:
            histogram = histogram.reshape(1, -1)

        return histogram


def keygen(user_id, fingerprint_image_path):
    master_public, master_secret = sm9.setup('sign')
    private_key = sm9.private_key_extract('sign', master_public, master_secret, user_id)

    # Extract fingerprint features
    enrollment_features = SimpleBiometricLibrary.extract_features(fingerprint_image_path)

    return master_public, private_key, enrollment_features



def sign(master_public, private_key, message):
    signature = sm9.sign(master_public, private_key, message)
    return signature

def verify(master_public, user_id, enrollment_features, fingerprint_image_path, message, signature):
    is_valid = sm9.verify(master_public, user_id, message, signature)

    if not is_valid:
        return False

    verification_features = SimpleBiometricLibrary.extract_features(fingerprint_image_path)

    # Compute cosine similarity between the enrollment and verification features
    cosine_similarity = 1 - cosine(enrollment_features.flatten(), verification_features.flatten())

    # Set a threshold to determine if the signature is valid
    
    return cosine_similarity > 0.7


 



if __name__ == "__main__":
    user_id = "Alice"
    enrollment_fingerprint_image_path = "/home/sunci/Pictures/omg.jpg"
    master_public, private_key, enrollment_features = keygen(user_id, enrollment_fingerprint_image_path)
    message = "Hello, world!"
    signature = sign(master_public, private_key, message)

    verification_fingerprint_image_path = "/home/sunci/Pictures/omg.jpg"
    is_valid = verify(master_public, user_id, enrollment_features, verification_fingerprint_image_path, message, signature)

    if is_valid:
        print("Signature is valid.")
    else:
        print("Signature is invalid.")


